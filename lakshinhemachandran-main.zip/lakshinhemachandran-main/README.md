
[![Discord Presence](https://lanyard.cnrad.dev/api/1333091618055655448)](https://discord.com/users/1333091618055655448)

